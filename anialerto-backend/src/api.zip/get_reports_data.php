<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

error_reporting(0);
ini_set('display_errors', 0);

mysqli_report(MYSQLI_REPORT_OFF);

if (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false || strpos($_SERVER['SERVER_NAME'], 'localhost') !== false) {
    $conn = new mysqli("localhost", "root", "", "anialerto");
} else {
    $conn = new mysqli("localhost", "u268935662_anialerto123", "AniAlerto123", "u268935662_AniAlerto");
}

if ($conn->connect_error) {
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Helpers
function safeRows($conn, $sql) {
    $res = $conn->query($sql);
    if (!$res || $res === true) return [];
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}

// Filters
$batch_id   = isset($_GET['batch_id']) ? intval($_GET['batch_id']) : 0;
$worker_id  = isset($_GET['worker_id']) ? intval($_GET['worker_id']) : 0;
$category   = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';
$start_date = isset($_GET['start_date']) ? $conn->real_escape_string($_GET['start_date']) : '';
$end_date   = isset($_GET['end_date']) ? $conn->real_escape_string($_GET['end_date']) : '';

// Base conditions
$task_conds = ["1=1"];
if ($batch_id > 0) $task_conds[] = "st.batch_id = $batch_id";
if ($category)     $task_conds[] = "mt.category = '$category'";
if ($start_date)   $task_conds[] = "DATE(st.due_date) >= '$start_date'";
if ($end_date)     $task_conds[] = "DATE(st.due_date) <= '$end_date'";
$task_where = implode(" AND ", $task_conds);

$log_conds = ["1=1"];
if ($worker_id > 0) $log_conds[] = "sl.worker_id = $worker_id";
if ($start_date)    $log_conds[] = "DATE(sl.created_at) >= '$start_date'";
if ($end_date)      $log_conds[] = "DATE(sl.created_at) <= '$end_date'";
$log_where = implode(" AND ", $log_conds);

$export_log_conds = $log_conds;
if ($batch_id > 0) $export_log_conds[] = "st.batch_id = $batch_id";
$export_log_where = implode(" AND ", $export_log_conds);


// ==========================================
// CORE REPORT 1: ACTIVITY / OPERATIONAL
// ==========================================
$activityReport = [
    "taskExecution" => [
        "assigned" => 0, "done" => 0, "delayedDone" => 0, "delay" => 0, "overdue" => 0
    ],
    "smsAdvisoryLogs" => [
        "sent" => 0, "failed" => 0, "pending" => 0
    ],
    "workerResponses" => [
        "done" => 0, "help" => 0, "pest" => 0, "delay" => 0
    ],
    "systemAlerts" => [],
    "recentLogs" => []
];

// Task Execution (DONE vs DELAYED DONE based on completion date vs due date)
$tasks = safeRows($conn, "SELECT st.status, st.due_date, st.completed_at FROM scheduled_tasks st JOIN message_templates mt ON st.template_id = mt.id WHERE $task_where");
foreach($tasks as $t) {
    $activityReport["taskExecution"]["assigned"]++;
    if ($t['status'] === 'Completed') {
        if ($t['completed_at'] && $t['due_date'] && date('Y-m-d', strtotime($t['completed_at'])) > date('Y-m-d', strtotime($t['due_date']))) {
            $activityReport["taskExecution"]["delayedDone"]++;
        } else {
            $activityReport["taskExecution"]["done"]++;
        }
    } else if ($t['status'] === 'Delayed') {
        $activityReport["taskExecution"]["delay"]++;
    } else if ($t['status'] === 'Pending' && $t['due_date'] < date('Y-m-d')) {
        $activityReport["taskExecution"]["overdue"]++;
    }
}

// SMS Advisory Logs (Outbound)
$outbound = safeRows($conn, "SELECT status, COUNT(*) as cnt FROM sms_logs sl WHERE direction = 'Inbound' AND $log_where GROUP BY status"); // Wait, system -> worker is 'Inbound' in this DB? Actually, let's assume system outbound is 'Inbound' in db if 'Outbound' is from worker. Let me check: In previous scripts, `Outbound` was worker->system. `Inbound` was system->worker. Let me use 'Inbound' as SYSTEM->WORKER and 'Outbound' as WORKER->SYSTEM for now, based on previous query WHERE sl.direction = 'Outbound' capturing 'DONE'. Yes!
// Wait! `sms_queue` has the actual sent status.
$smsQueue = safeRows($conn, "SELECT status, COUNT(*) as cnt FROM sms_queue sq WHERE 1=1 GROUP BY status");
foreach($smsQueue as $q) {
    $stat = strtolower($q['status']);
    if ($stat === 'sent') $activityReport["smsAdvisoryLogs"]["sent"] += (int)$q['cnt'];
    else if ($stat === 'failed') $activityReport["smsAdvisoryLogs"]["failed"] += (int)$q['cnt'];
    else $activityReport["smsAdvisoryLogs"]["pending"] += (int)$q['cnt'];
}

// Worker Responses (Outbound = Worker -> System)
$workerResp = safeRows($conn, "SELECT response_text FROM sms_logs sl WHERE direction = 'Outbound' AND $log_where");
foreach($workerResp as $r) {
    $txt = strtoupper($r['response_text']);
    if ($txt === 'DONE') $activityReport["workerResponses"]["done"]++;
    else if (strpos($txt, 'HELP') === 0) $activityReport["workerResponses"]["help"]++;
    else if ($txt === 'PEST' || $txt === 'UOD') $activityReport["workerResponses"]["pest"]++;
    else if (strpos($txt, 'DELAY') === 0) $activityReport["workerResponses"]["delay"]++;
}

$activityReport["recentLogs"] = safeRows($conn, "
    SELECT sl.created_at as timestamp, w.name as workerName, sl.response_text, sl.status
    FROM sms_logs sl
    JOIN workers w ON sl.worker_id = w.id
    WHERE sl.direction = 'Outbound' AND $log_where
    ORDER BY sl.created_at DESC LIMIT 10
");


// ==========================================
// CORE REPORT 2: ANALYTICAL / SUMMARY
// ==========================================
$analyticalReport = [
    "systemEffectiveness" => [
        "taskCompletionRate" => 0,
        "workerResponsivenessRate" => 0,
        "smsDeliverySuccessRate" => 0
    ],
    "problemHotspots" => [
        "help" => [], "pest" => [], "delay" => []
    ],
    "workerRankings" => []
];

// System Effectiveness
$totalTask = $activityReport["taskExecution"]["assigned"];
if ($totalTask > 0) {
    $analyticalReport["systemEffectiveness"]["taskCompletionRate"] = round((($activityReport["taskExecution"]["done"] + $activityReport["taskExecution"]["delayedDone"]) / $totalTask) * 100);
}
$totalQueue = $activityReport["smsAdvisoryLogs"]["sent"] + $activityReport["smsAdvisoryLogs"]["failed"] + $activityReport["smsAdvisoryLogs"]["pending"];
if ($totalQueue > 0) {
    $analyticalReport["systemEffectiveness"]["smsDeliverySuccessRate"] = round(($activityReport["smsAdvisoryLogs"]["sent"] / $totalQueue) * 100);
}

// Problem Hotspots
foreach($workerResp as $r) {
    $txt = strtoupper($r['response_text']);
    if (strpos($txt, 'HELP:') === 0) {
        $reason = trim(substr($txt, 5));
        $analyticalReport["problemHotspots"]["help"][$reason] = ($analyticalReport["problemHotspots"]["help"][$reason] ?? 0) + 1;
    } else if ($txt === 'PEST' || $txt === 'UOD') {
        $analyticalReport["problemHotspots"]["pest"]['Pest Infection'] = ($analyticalReport["problemHotspots"]["pest"]['Pest Infection'] ?? 0) + 1;
    } else if (strpos($txt, 'DELAY:') === 0) {
        $reason = trim(substr($txt, 6));
        $analyticalReport["problemHotspots"]["delay"][$reason] = ($analyticalReport["problemHotspots"]["delay"][$reason] ?? 0) + 1;
    }
}
// Transform associative arrays to flattened arrays for React
$flatHelp = []; foreach($analyticalReport["problemHotspots"]["help"] as $k=>$v) $flatHelp[] = ["category"=>$k, "count"=>$v];
$flatPest = []; foreach($analyticalReport["problemHotspots"]["pest"] as $k=>$v) $flatPest[] = ["category"=>$k, "count"=>$v];
$flatDelay = []; foreach($analyticalReport["problemHotspots"]["delay"] as $k=>$v) $flatDelay[] = ["category"=>$k, "count"=>$v];
$analyticalReport["problemHotspots"]["help"] = $flatHelp;
$analyticalReport["problemHotspots"]["pest"] = $flatPest;
$analyticalReport["problemHotspots"]["delay"] = $flatDelay;

// Worker Performance Ranking
$workersQuery = safeRows($conn, "
    SELECT w.id, w.name,
           (SELECT COUNT(*) FROM sms_logs sl_in WHERE sl_in.worker_id = w.id AND sl_in.direction = 'Inbound') as systemSent,
           (SELECT COUNT(*) FROM sms_logs sl_out WHERE sl_out.worker_id = w.id AND sl_out.direction = 'Outbound') as workerReplied,
           SUM(CASE WHEN sl.response_text = 'DONE' THEN 1 ELSE 0 END) as doneCount,
           SUM(CASE WHEN sl.response_text LIKE 'DELAY%' THEN 1 ELSE 0 END) as delayCount,
           SUM(CASE WHEN sl.response_text LIKE 'HELP%' THEN 1 ELSE 0 END) as helpCount,
           SUM(CASE WHEN sl.response_text IN ('PEST','UOD') THEN 1 ELSE 0 END) as pestCount
    FROM workers w
    LEFT JOIN sms_logs sl ON w.id = sl.worker_id AND sl.direction = 'Outbound'
    WHERE w.status = 'Active'
    GROUP BY w.id, w.name
");

$workerRanks = [];
$totalSystemSent = 0;
$totalWorkerReplied = 0;

foreach($workersQuery as $wq) {
    $sent = (int)$wq['systemSent'];
    $replied = (int)$wq['workerReplied'];
    $totalSystemSent += $sent;
    $totalWorkerReplied += $replied;
    
    $respRate = $sent > 0 ? round(($replied / $sent) * 100) : 0;
    $unresponsive = max(0, $sent - $replied);
    
    // Custom Rank Score: Responsive + High Done - Delays - Unresponsive
    $score = $respRate + ($wq['doneCount'] * 2) - ($wq['delayCount'] * 5) - ($unresponsive * 2);
    
    $workerRanks[] = [
        "id" => $wq['id'], "name" => $wq['name'],
        "sent" => $sent, "replied" => $replied,
        "responsiveness" => $respRate,
        "unresponsiveIncidents" => $unresponsive,
        "done" => $wq['doneCount'],
        "delay" => $wq['delayCount'],
        "help" => $wq['helpCount'],
        "pest" => $wq['pestCount'],
        "score" => $score
    ];
}
usort($workerRanks, function($a, $b) { return $b['score'] <=> $a['score']; });
$analyticalReport["workerRankings"] = $workerRanks;

if ($totalSystemSent > 0) {
    $analyticalReport["systemEffectiveness"]["workerResponsivenessRate"] = round(($totalWorkerReplied / $totalSystemSent) * 100);
}


// ==========================================
// CORE REPORT 3: EXPORT (DEEP DIVE)
// ==========================================
$exportReport = [
    "metadata" => [
        "generatedAt" => date('Y-m-d H:i:s'),
        "filtersUsed" => "Batch: " . ($batch_id ?: 'All') . " | Worker: " . ($worker_id ?: 'All') . " | Range: " . ($start_date ?: 'All Time')
    ],
    "aggregated" => [
        "responsiveness" => 0,
        "doneCount" => 0, "delayCount" => 0, "unresponsiveCount" => 0
    ],
    "logs" => []
];

// We compute aggregated just for the currently filtered set
$f_sent = 0; $f_replied = 0; $f_done = 0; $f_delay = 0;
foreach($workerRanks as $wr) {
    if ($worker_id > 0 && $wr['id'] != $worker_id) continue;
    $f_sent += $wr['sent'];
    $f_replied += $wr['replied'];
    $f_done += $wr['done'];
    $f_delay += $wr['delay'];
}
$exportReport["aggregated"]["responsiveness"] = $f_sent > 0 ? round(($f_replied / $f_sent) * 100) : 0;
$exportReport["aggregated"]["unresponsiveCount"] = max(0, $f_sent - $f_replied);
$exportReport["aggregated"]["doneCount"] = $f_done;
$exportReport["aggregated"]["delayCount"] = $f_delay;

$deepLogs = safeRows($conn, "
    SELECT sl.created_at, w.name as workerName, sl.direction, sl.response_text, sl.status, mt.name as taskName, fb.name as batchName
    FROM sms_logs sl
    LEFT JOIN workers w ON sl.worker_id = w.id
    LEFT JOIN scheduled_tasks st ON sl.task_id = st.id
    LEFT JOIN message_templates mt ON st.template_id = mt.id
    LEFT JOIN farm_batches fb ON mt.batch_id = fb.id
    WHERE sl.direction = 'Outbound' AND $export_log_where
    ORDER BY sl.created_at DESC
    LIMIT 500
");
$exportReport["logs"] = $deepLogs;

// Fetch Filter Options
$filterOptions = [
    "batches" => safeRows($conn, "SELECT id, name FROM farm_batches ORDER BY name"),
    "workers" => safeRows($conn, "SELECT id, name FROM workers WHERE status='Active' ORDER BY name"),
    "categories" => safeRows($conn, "SELECT DISTINCT category FROM message_templates WHERE category IS NOT NULL ORDER BY category")
];

echo json_encode([
    "activityReport" => $activityReport,
    "analyticalReport" => $analyticalReport,
    "exportReport" => $exportReport,
    "filterOptions" => $filterOptions
]);

$conn->close();
?>